/*
ns * CallBackFnc.cpp
 *
 *  Created on: 29 окт. 2015 г.
 *      Author: makcum
 */

#include "CallBackFnc.h"

CallBackFnc::CallBackFnc(){
	func=0;
}

void CallBackFnc::setFunk(void * f){
	this->func = (func_t)f;
}


bool CallBackFnc::operator()(struct can_frame *frameIn, struct can_frame *frameOut){
	bool flag = false;
	if(func != 0) flag = (*func)(frameIn, frameOut);
	return flag;
}



void CallBackFnc::test(){
	struct can_frame frame;
	if(func != 0) (*func)(&frame, &frame);
}

