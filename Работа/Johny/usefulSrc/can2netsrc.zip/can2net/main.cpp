/*
 * 		can2net
 * 		Программа аналог ser2net, для работы CAN шиной
 *
 * 		Для работы со светодиодом требуюся права администратора sudo/root
 *
 *      Author: makcum
 *      version: 1.0
 */


#include "helper.h"
#include "CallBackFnc.h"

// Чтение из шины CAN
void* threadCanRead( void *pThreadAtrr);
bool isTCPSocket = false;

//Глобальные переменные, связанные с сокетами
int sock;
int canSock;

CallBackFnc handler;

int main(int argc, char** argv)
{
	void *library_handler; // хандлер внешней библиотеки
	if(argc > 1)
	{
		library_handler = dlopen(argv[1], RTLD_LAZY);
		if (!library_handler)
		{
			//если ошибка, то вывести ее на экран
			fprintf(stderr,"dlopen() error: %s\n", dlerror());
		};


		if(library_handler)
		{
			handler.setFunk( dlsym(library_handler, "frameAnalize") );
		}
	}

	// initialize CAN bus
	if(initCanSocket(&canSock, "can0") != 0)
	{
		printf("Ошибка инициализации can bus\n");
		return 0;
	}

	// initialize server TCP/ip
	int listener;
	int port = 13133;
	if(initTCPServer(&listener, port) != 0)
	{
		printf("Ошибка инициализации tcp/ip server: listener \n");
		return 0;
	}

	// init reader CAN BUS
	pthread_t thread;
	pthread_create(&thread, NULL, &threadCanRead, NULL);

    while(1)
    {
        sock = accept(listener, 0, 0);//определяем текущего клиента
        if(sock < 0){
        	printf("Неудача инициализации сокета на сервере\n");
            return 0;
        }

        isTCPSocket = true; // Даем разрежение на чтение из CAN шины

        while(1)//обрабатываем сообщения текущего клиента
        {
    		struct can_frame frame; // буфер
    		struct can_frame frame_answer; // буфер

    		int bytes_read = recv(sock, &frame, sizeof(frame), 0);
            if(bytes_read <= 0) break; //значит клиент отсоеденился - выходим из цикла и ждем появления нового клиента

            // перекидываем полученные can структуры  в can шину
            write(canSock, &frame, sizeof(struct can_frame));

    		// Передаем обработчику данного устройства (говорим что отправили какой-то пакет)
    		bool isFlag = handler(&frame, &frame_answer);

        }

        isTCPSocket = false; // Запрещаем чтение из CAN шины
        close(sock); //закрываем текущее соединение
        sleepSelect(0, 100000);
    }


    // Закрываем динамически подключенную библиотеку
    dlclose(library_handler);

	return 0;
}

void* threadCanRead( void *pThreadAtrr)
{
	struct can_frame frame; // буфер
	struct can_frame frame_answer; // буфер

	while(true)
	{
		read(canSock, &frame, sizeof(frame));

		// Передаем обработчику данного устройства
		bool isFlag = handler(&frame, &frame_answer);

		// Если обработчик сформировал ответ, то отправим его в CAN шину
		if(isFlag) write(canSock, &frame_answer, sizeof(struct can_frame));

		if(isTCPSocket)
		{
			write(sock, &frame, sizeof(frame));
		}
	}

}
