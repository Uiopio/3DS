/*
 * helper.cpp
 *
 *  Created on: 21 сент. 2015 г.
 *      Author: makcum
 */

#include "helper.h"



int initCanSocket(int *sock,const char* interface){
	int s;
	struct sockaddr_can addr;
	struct ifreq ifr;

	// Указываем с каким устройством будем работать
	//char *interface = "can0";

	s = socket(PF_CAN, SOCK_RAW, CAN_RAW);

	if( s < 0) {
		perror("Error while opening socket");
		return -1;
	}

	strcpy(ifr.ifr_name, interface);
	ioctl(s, SIOCGIFINDEX, &ifr);

	addr.can_family  = AF_CAN;
	addr.can_ifindex = ifr.ifr_ifindex;

	if(bind(s, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
		perror("Error in socket bind");
		return -1;
	}

	(*sock) = s;

	return 0;
}


int initTCPServer(int *Listener, int port){
	int listener;
	struct sockaddr_in addr;

	listener = socket(AF_INET, SOCK_STREAM, 0);
		if(listener < 0){
	        perror("socket");
	        return -1;
	    }

	addr.sin_family = AF_INET;
	addr.sin_port = htons(port);
	addr.sin_addr.s_addr = htonl(INADDR_ANY);
	if(bind(listener, (struct sockaddr *)&addr, sizeof(addr)) < 0){
	        perror("bind");
	        return -1;
	}

	listen(listener, 1);
	//конец настройки сервера tcp/ip

	(*Listener) = listener;

	return 0;
}

int sleepSelect(int sec, int usec){
	struct timeval tv;

    tv.tv_sec = sec;
    tv.tv_usec = usec;

    return select(1, NULL, NULL, NULL, &tv);
}


