/*
 * CallBackFnc.h
 *
 *  Created on: 29 окт. 2015 г.
 *      Author: makcum
 */

#ifndef CALLBACKFNC_H_
#define CALLBACKFNC_H_

#include <linux/can.h>
#include <iostream>

class CallBackFnc {
	typedef bool (*func_t)(struct can_frame *frameIn, struct can_frame *frameOut);

	func_t func;
public:
	CallBackFnc();

	void setFunk(void * f);

	bool operator()(struct can_frame *frameIn, struct can_frame *frameOut);

	void test();
};


#endif /* CALLBACKFNC_H_ */
