#include <iostream>
#include <linux/can.h>
#include "helper.h"

using namespace std;

// Работа с сокетом LED
void initLed();
void* threadLed( void *pThreadAtrr);
bool isLed=false;
/*
 * Путем отправки команд операционной системе делаем миганиния светодиода
 */
void* threadLed( void *pThreadAtrr){
	while(true){
		if(isLed){
			system("echo \"1\" > /sys/class/gpio/gpio4/value");
			sleepSelect(0, 100000);
			system("echo \"0\" > /sys/class/gpio/gpio4/value");
			sleepSelect(0, 100000);

			system("echo \"1\" > /sys/class/gpio/gpio4/value");
			sleepSelect(0, 100000);
			system("echo \"0\" > /sys/class/gpio/gpio4/value");

			isLed = false;
		}

		sleepSelect(0, 100000);
	}
}

// Инициализация светодиода
void initLed(){
	system("echo \"4\" > /sys/class/gpio/export");
	system("echo \"out\" > /sys/class/gpio/gpio4/direction");
	system("echo \"0\" > /sys/class/gpio/gpio4/value");
	pthread_t thread;
	pthread_create(&thread, NULL, &threadLed, NULL);
}


// Функция которая снаружи вешается на CAN шину
// frameIn - прослушенный фрейм;
// frameOut - фрейма ответа, актуален только тогда когда return ф-и возвращает true
extern "C" bool frameAnalize(struct can_frame *frameIn, struct can_frame *frameOut){
	bool flag = false;

	static bool isFirst = false;
	if(!isFirst){// инициализая первого вызова фунции

		// инициализация светодиода
		initLed();

		// конец инициализации
		isFirst = true;
	}

	isLed = true;

	return flag;
}
