/*
 * helper.h
 *
 *  Created on: 21 сент. 2015 г.
 *      Author: makcum
 */

#ifndef HELPER_H_
#define HELPER_H_

#include <iostream>
#include <sstream>
#include <string>
#include <time.h>
#include <stdint.h>
#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>


#include <sys/select.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>


#include <string.h>


#include <net/if.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/un.h>
#include <netinet/in.h>

#include <linux/can.h>
#include <linux/can/raw.h>



// Инициализация сокета canbus
// Пример вызова:   initCanSocket(&s, "can0")
int initCanSocket(int *sock, const char* interface);

// Инициализация servera TCP/ip
int initTCPServer(int *Listener, int port);

// функция слип которая освобаждает ресурсы для от потока
int sleepSelect(int sec, int usec);




#endif /* HELPER_H_ */
